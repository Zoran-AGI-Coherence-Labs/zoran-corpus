import numpy as np
from scipy.stats import entropy

def calculate_c_phi(P, Q):
    return entropy(P, Q)

P = np.array([0.95, 0.05])
Q = np.array([0.50, 0.50])

c_phi = calculate_c_phi(P, Q)
print(c_phi, "Persistance" if c_phi > 0 else "Dissolution")
