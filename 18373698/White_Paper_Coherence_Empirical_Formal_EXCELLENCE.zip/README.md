# Zenodo Package — Excellence Build

**DOI (this white paper):** https://doi.org/10.5281/zenodo.18373698

## Titles
- EN: When Empirical Evidence Meets Formal Proof: Coherence as a Universal Constraint on Cognition
- FR: Quand l’empirique rejoint la démonstration formelle : la cohérence comme contrainte universelle de la cognition

## Files
- white_paper_EN.md — English master
- white_paper_FR.md — French master
- white_paper_EN.pdf — Typeset PDF (English)
- white_paper_FR.pdf — Typeset PDF (French)
- bibliography.md — Formal references (DOI / URL)
- references.bib — BibTeX
- CITATION.cff — Citation metadata
- zenodo_metadata.json — Minimal Zenodo metadata
- CHECK_360.md — Integrity report (line-level)
- SHA512SUMS.txt — SHA-512 checksums

## Build time (UTC)
2026-01-26T09:05:57Z
