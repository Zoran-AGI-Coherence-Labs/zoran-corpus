# Zenodo metadata (companion)

## Title
La cohérence comme condition nécessaire de persistance pour seize problématiques majeures

## Reference DOI
https://doi.org/10.5281/zenodo.18305643

## Release date
2026-01-20

## Abstract (short)
This deposit contains the master White Paper (PDF) proposing a falsifiable transversal constraint: coherence as temporal compatibility of successive system states without growing compensation. It formalizes an evaluative gauge (S, ΔS) and applies it by saturation across sixteen major problem domains, plus a meta-epistemic post-scriptum on validation (humans vs AI multi-reading). The work is non-predictive and non-normative; it provides admissibility conditions for persistence and explicit falsifiability via counterexample.

## Files
- WP_Coherence_Final.pdf (master document)
- SHA512i.txt (integrity hash for the PDF)
- LICENSE_MIT.txt (open-core license)
- LICENSE_COMMERCIAL.txt (commercial-use terms)

## Keywords
coherence, persistence, complex systems, trajectory admissibility, compensation growth, non-resolution, systems theory, AI alignment, energy systems, climate tipping points, cognitive persistence, epistemology

## Classifications
### MeSH
- Systems Theory (MeSH)
- Homeostasis (MeSH)
- Biological Complexity (MeSH)
- Disease Progression (MeSH)
- Energy Metabolism (MeSH)
- Decision Making (MeSH)
- Risk Assessment (MeSH)
- Models, Theoretical (MeSH)

### JEL
- D81 (JEL)
- D70 (JEL)
- H12 (JEL)
- O33 (JEL)
- Q40 (JEL)
- Q54 (JEL)
- B41 (JEL)

## Related DOIs (core corpus referenced)
- https://doi.org/10.5281/zenodo.18183572
- https://doi.org/10.5281/zenodo.18183955
- https://zenodo.org/records/17977201
- https://zenodo.org/records/18064508
- https://zenodo.org/records/18281177
- https://zenodo.org/records/17915416
- https://doi.org/10.5281/zenodo.18283418
- https://doi.org/10.5281/zenodo.18284318
- https://zenodo.org/records/18093709
- https://zenodo.org/records/18244890
- https://zenodo.org/records/18058115
- https://zenodo.org/records/18300445
- https://zenodo.org/records/18189165
- https://zenodo.org/records/17699590
- https://zenodo.org/records/18297352
- https://zenodo.org/records/18298563
- https://zenodo.org/records/18298889
- https://zenodo.org/records/18143178

## License
MIT (open core) for the accompanying text/artifacts, plus separate commercial license for industrial/professional use.

## Contact
Frédéric Tabary
INSTITUT🦋 IA INC.
7100-380, rue Saint-Antoine Ouest, Montréal (Québec) H2Y 3X7
Angers, France
Tabary01@gmail.com
