Proofs bundle placeholder. No proofs generated in sandbox.
Expected: signed artifacts, Rekor inclusion proofs, TSA timestamps.