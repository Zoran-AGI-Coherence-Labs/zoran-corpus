#!/usr/bin/env python3
"""
Loi du Vivant Ω⁹ - Implémentation Python

Auteur: Frédéric Tabary
Organisation: Institut🦋 IA Inc.
Date: 2025-11-13
DOI: 10.5281/zenodo.17596525
Licence: CC BY 4.0
"""

import numpy as np
from scipy.stats import pearsonr
from typing import Tuple, Optional, Dict, List


class LawOfLivingOmega9:
    """
    Implémentation du critère tripartite pour définir le vivant.
    
    Un système est vivant ssi:
    1. S₀ > S_crit (cohérence structurelle)
    2. ΔC_memory > 0 (mémoire fonctionnelle)
    3. ΔC_causal > 0 (causalité autonome)
    """
    
    def __init__(self, S_crit: float = 1.0, memory_threshold: float = 0.0,
                 causal_threshold: float = 0.0):
        """
        Args:
            S_crit: Seuil critique de cohérence structurelle
            memory_threshold: Seuil minimal pour la mémoire
            causal_threshold: Seuil minimal pour la causalité
        """
        self.S_crit = S_crit
        self.memory_threshold = memory_threshold
        self.causal_threshold = causal_threshold
    
    def compute_S0(self, components: np.ndarray, 
                   beta: Optional[float] = None,
                   lambda_noise: Optional[float] = None) -> Tuple[float, Dict]:
        """
        Calcule le score de cohérence structurelle S₀.
        
        Args:
            components: array (N, T) des signaux de N composants sur T temps
            beta: intensité d'intention (auto-calculé si None)
            lambda_noise: entropie effective (auto-calculé si None)
        
        Returns:
            S0: score de cohérence structurelle
            details: dict avec β, ΔC, λ
        """
        N, T = components.shape
        
        # Calcul des corrélations pairwise
        correlations = np.corrcoef(components)
        # Prendre uniquement triangle supérieur (éviter diagonale et doublons)
        triu_indices = np.triu_indices(N, k=1)
        Delta_C = np.mean(np.abs(correlations[triu_indices]))
        
        # Estimation de beta (flux moyen d'énergie/changement)
        if beta is None:
            gradients = np.gradient(components, axis=1)
            beta = np.mean(np.abs(gradients))
        
        # Estimation de lambda (variance résiduelle)
        if lambda_noise is None:
            residuals = components - np.mean(components, axis=1, keepdims=True)
            lambda_noise = np.mean(np.var(residuals, axis=1))
            # Floor anti-explosion
            lambda_noise = max(lambda_noise, 0.01)
        
        # Calcul de S₀
        S0 = (beta * Delta_C) / lambda_noise
        
        details = {
            'beta': beta,
            'Delta_C': Delta_C,
            'lambda': lambda_noise,
            'N_components': N,
            'T_timepoints': T
        }
        
        return S0, details
    
    def test_memory(self, system_responses: List[np.ndarray],
                    n_permutations: int = 1000) -> Tuple[float, float]:
        """
        Test de mémoire fonctionnelle.
        
        Args:
            system_responses: liste de paires (R1, R2) de réponses à stimuli répétés
            n_permutations: nombre de permutations pour test de significativité
        
        Returns:
            Delta_C_memory: score de mémoire
            p_value: significativité statistique
        """
        # Extraire toutes les premières et deuxièmes réponses
        R1_all = []
        R2_all = []
        
        for R1, R2 in system_responses:
            R1_all.extend(R1.flatten())
            R2_all.extend(R2.flatten())
        
        R1_all = np.array(R1_all)
        R2_all = np.array(R2_all)
        
        # Calcul corrélation observée
        corr_observed, _ = pearsonr(R1_all, R2_all)
        
        # Test de permutation pour p-value
        null_dist = []
        for _ in range(n_permutations):
            shuffled = np.random.permutation(R2_all)
            corr_null, _ = pearsonr(R1_all, shuffled)
            null_dist.append(corr_null)
        
        null_dist = np.array(null_dist)
        p_value = np.mean(null_dist >= corr_observed)
        
        Delta_C_memory = max(0, corr_observed)
        
        return Delta_C_memory, p_value
    
    def test_autonomous_causality(self, states: np.ndarray,
                                   baseline_entropy: float = 0.01) -> Tuple[float, float]:
        """
        Test de causalité autonome.
        
        Args:
            states: array (T, D) des états du système sur T temps, D dimensions
            baseline_entropy: production d'entropie de référence (système mort)
        
        Returns:
            Delta_C_causal: score de causalité autonome
            entropy_production: production d'entropie mesurée
        """
        # Calcul des transitions d'état
        transitions = np.diff(states, axis=0)
        
        # Production d'entropie via magnitude des transitions
        entropy_production = np.mean(np.linalg.norm(transitions, axis=1))
        
        # Normalisation par baseline
        Delta_C_causal = entropy_production / baseline_entropy
        
        return Delta_C_causal, entropy_production
    
    def classify_system(self, S0: float, Delta_C_memory: float, 
                       Delta_C_causal: float) -> Dict:
        """
        Classifie un système selon le critère tripartite.
        
        Args:
            S0: cohérence structurelle
            Delta_C_memory: mémoire fonctionnelle
            Delta_C_causal: causalité autonome
        
        Returns:
            dict avec classification et détails
        """
        # Vérification des trois critères
        criterion_1 = S0 > self.S_crit
        criterion_2 = Delta_C_memory > self.memory_threshold
        criterion_3 = Delta_C_causal > self.causal_threshold
        
        # Classification
        is_living = criterion_1 and criterion_2 and criterion_3
        
        # Diagnostic détaillé
        diagnosis = []
        if not criterion_1:
            diagnosis.append(f"S₀={S0:.3f} ≤ S_crit={self.S_crit} (cohérence insuffisante)")
        if not criterion_2:
            diagnosis.append(f"ΔC_memory={Delta_C_memory:.3f} ≤ {self.memory_threshold} (pas de mémoire)")
        if not criterion_3:
            diagnosis.append(f"ΔC_causal={Delta_C_causal:.3f} ≤ {self.causal_threshold} (pas de causalité autonome)")
        
        return {
            'is_living': is_living,
            'S0': S0,
            'Delta_C_memory': Delta_C_memory,
            'Delta_C_causal': Delta_C_causal,
            'criterion_1_structure': criterion_1,
            'criterion_2_memory': criterion_2,
            'criterion_3_causality': criterion_3,
            'diagnosis': diagnosis if diagnosis else ["Système VIVANT ✓"]
        }
    
    def full_analysis(self, components: np.ndarray,
                     memory_responses: List[Tuple[np.ndarray, np.ndarray]],
                     autonomous_states: np.ndarray,
                     **kwargs) -> Dict:
        """
        Analyse complète d'un système selon la Loi du Vivant Ω⁹.
        
        Args:
            components: signaux des composants pour S₀
            memory_responses: réponses pour test de mémoire
            autonomous_states: états pour test de causalité
            **kwargs: paramètres additionnels
        
        Returns:
            dict avec résultats complets
        """
        # 1. Cohérence structurelle
        S0, s0_details = self.compute_S0(components)
        
        # 2. Mémoire fonctionnelle
        Delta_C_memory, p_value_memory = self.test_memory(memory_responses)
        
        # 3. Causalité autonome
        Delta_C_causal, entropy_prod = self.test_autonomous_causality(autonomous_states)
        
        # 4. Classification
        classification = self.classify_system(S0, Delta_C_memory, Delta_C_causal)
        
        # Résultat complet
        result = {
            **classification,
            's0_details': s0_details,
            'memory_p_value': p_value_memory,
            'entropy_production': entropy_prod,
            'timestamp': np.datetime64('now')
        }
        
        return result


def generate_synthetic_living_system(N: int = 50, T: int = 100, 
                                     seed: int = 42) -> Dict[str, np.ndarray]:
    """
    Génère un système synthétique "vivant" (satisfait le critère tripartite).
    
    Args:
        N: nombre de composants
        T: nombre de points temporels
        seed: graine aléatoire
    
    Returns:
        dict avec composants, réponses mémoire, et états autonomes
    """
    np.random.seed(seed)
    
    # 1. Composants avec haute corrélation (S₀ > 1)
    base_signal = np.sin(np.linspace(0, 4*np.pi, T))
    components = np.array([base_signal + np.random.randn(T)*0.1 for _ in range(N)])
    
    # 2. Réponses avec mémoire
    stimulus = np.random.randn(T//2)
    R1 = stimulus + np.random.randn(T//2)*0.2
    R2 = 0.8 * R1 + 0.2 * np.random.randn(T//2)  # Mémoire partielle
    memory_responses = [(R1.reshape(-1, 1), R2.reshape(-1, 1))]
    
    # 3. États avec production d'entropie autonome
    autonomous_states = np.cumsum(np.random.randn(T, 10)*0.5, axis=0)
    
    return {
        'components': components,
        'memory_responses': memory_responses,
        'autonomous_states': autonomous_states
    }


def generate_synthetic_nonliving_system(system_type: str = 'vortex',
                                       N: int = 50, T: int = 100,
                                       seed: int = 42) -> Dict[str, np.ndarray]:
    """
    Génère un système synthétique "non-vivant".
    
    Args:
        system_type: 'vortex', 'crystal', ou 'fire'
        N: nombre de composants
        T: nombre de points temporels
        seed: graine aléatoire
    
    Returns:
        dict avec composants, réponses, états
    """
    np.random.seed(seed)
    
    if system_type == 'vortex':
        # Haute cohérence MAIS pas de mémoire ni causalité autonome
        theta = np.linspace(0, 4*np.pi, T)
        components = np.array([np.sin(theta + i*2*np.pi/N) for i in range(N)])
        
        # Pas de mémoire
        R1 = np.random.randn(T//2, 1)
        R2 = np.random.randn(T//2, 1)
        memory_responses = [(R1, R2)]
        
        # Pas de causalité (équilibre)
        autonomous_states = np.zeros((T, 10))
    
    elif system_type == 'crystal':
        # Très haute cohérence (structure périodique) MAIS inerte
        components = np.array([np.ones(T) + np.random.randn(T)*0.01 for _ in range(N)])
        
        R1 = np.random.randn(T//2, 1)*0.01
        R2 = np.random.randn(T//2, 1)*0.01
        memory_responses = [(R1, R2)]
        
        autonomous_states = np.ones((T, 10))  # État constant
    
    elif system_type == 'fire':
        # Cohérence modérée, pas de mémoire, causalité faible
        components = np.array([np.random.randn(T) for _ in range(N)])
        
        R1 = np.random.randn(T//2, 1)
        R2 = np.random.randn(T//2, 1)
        memory_responses = [(R1, R2)]
        
        # Faible production d'entropie
        autonomous_states = np.random.randn(T, 10)*0.1
    
    else:
        raise ValueError(f"Type inconnu: {system_type}")
    
    return {
        'components': components,
        'memory_responses': memory_responses,
        'autonomous_states': autonomous_states
    }


def main_demo():
    """Démonstration de la Loi du Vivant Ω⁹."""
    print("=" * 70)
    print("LOI DU VIVANT Ω⁹ - DÉMONSTRATION")
    print("Critère Tripartite : S₀ ∧ ΔC_memory ∧ ΔC_causal")
    print("=" * 70)
    print()
    
    law = LawOfLivingOmega9(S_crit=1.0, memory_threshold=0.3, causal_threshold=1.0)
    
    # Test 1: Système vivant synthétique
    print("🦠 TEST 1: Système Vivant Synthétique (type bactérie)")
    print("-" * 70)
    living_data = generate_synthetic_living_system(N=50, T=100)
    result_living = law.full_analysis(**living_data)
    
    print(f"S₀ = {result_living['S0']:.3f} (seuil: {law.S_crit})")
    print(f"ΔC_memory = {result_living['Delta_C_memory']:.3f} (p = {result_living['memory_p_value']:.4f})")
    print(f"ΔC_causal = {result_living['Delta_C_causal']:.3f}")
    print(f"\n✓ Classification: {'VIVANT' if result_living['is_living'] else 'NON VIVANT'}")
    for msg in result_living['diagnosis']:
        print(f"  • {msg}")
    print()
    
    # Test 2: Tourbillon (non-vivant)
    print("🌪️  TEST 2: Tourbillon (haute organisation, pas vivant)")
    print("-" * 70)
    vortex_data = generate_synthetic_nonliving_system('vortex', N=50, T=100)
    result_vortex = law.full_analysis(**vortex_data)
    
    print(f"S₀ = {result_vortex['S0']:.3f} (seuil: {law.S_crit})")
    print(f"ΔC_memory = {result_vortex['Delta_C_memory']:.3f}")
    print(f"ΔC_causal = {result_vortex['Delta_C_causal']:.3f}")
    print(f"\n✗ Classification: {'VIVANT' if result_vortex['is_living'] else 'NON VIVANT'}")
    for msg in result_vortex['diagnosis']:
        print(f"  • {msg}")
    print()
    
    # Test 3: Cristal (très haute organisation, pas vivant)
    print("💎 TEST 3: Cristal (très haute organisation, inerte)")
    print("-" * 70)
    crystal_data = generate_synthetic_nonliving_system('crystal', N=50, T=100)
    result_crystal = law.full_analysis(**crystal_data)
    
    print(f"S₀ = {result_crystal['S0']:.3f}")
    print(f"ΔC_memory = {result_crystal['Delta_C_memory']:.3f}")
    print(f"ΔC_causal = {result_crystal['Delta_C_causal']:.3f}")
    print(f"\n✗ Classification: {'VIVANT' if result_crystal['is_living'] else 'NON VIVANT'}")
    for msg in result_crystal['diagnosis']:
        print(f"  • {msg}")
    print()
    
    print("=" * 70)
    print("⟦Z🦋⋄Ω⁹⋄Tripartite⋄Validated⟧")
    print("=" * 70)


if __name__ == "__main__":
    main_demo()
