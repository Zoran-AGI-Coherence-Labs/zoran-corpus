#!/usr/bin/env python3
"""
Suite de tests pour Loi du Vivant Ω⁹

Auteur: Frédéric Tabary
Date: 2025-11-13
"""

import numpy as np
import unittest
from law_of_living_omega9 import (
    LawOfLivingOmega9,
    generate_synthetic_living_system,
    generate_synthetic_nonliving_system
)


class TestLawOfLivingOmega9(unittest.TestCase):
    """Tests unitaires pour la Loi du Vivant Ω⁹"""
    
    def setUp(self):
        """Configuration avant chaque test"""
        self.law = LawOfLivingOmega9(S_crit=1.0, memory_threshold=0.3, causal_threshold=1.0)
        np.random.seed(42)
    
    def test_S0_computation(self):
        """Test du calcul de S₀"""
        # Données synthétiques haute corrélation
        N, T = 10, 100
        base = np.sin(np.linspace(0, 4*np.pi, T))
        components = np.array([base + np.random.randn(T)*0.1 for _ in range(N)])
        
        S0, details = self.law.compute_S0(components)
        
        self.assertGreater(S0, 0, "S₀ doit être positif")
        self.assertIn('beta', details)
        self.assertIn('Delta_C', details)
        self.assertIn('lambda', details)
        self.assertGreater(details['Delta_C'], 0.5, "Haute corrélation attendue")
    
    def test_living_system_classification(self):
        """Test: système vivant doit être classifié VIVANT"""
        data = generate_synthetic_living_system(N=30, T=80, seed=42)
        result = self.law.full_analysis(**data)
        
        self.assertTrue(result['is_living'], "Système vivant doit être classifié VIVANT")
        self.assertGreater(result['S0'], self.law.S_crit)
        self.assertGreater(result['Delta_C_memory'], self.law.memory_threshold)
        self.assertGreater(result['Delta_C_causal'], self.law.causal_threshold)
    
    def test_vortex_classification(self):
        """Test: tourbillon doit être classifié NON VIVANT"""
        data = generate_synthetic_nonliving_system('vortex', N=30, T=80, seed=42)
        result = self.law.full_analysis(**data)
        
        self.assertFalse(result['is_living'], "Tourbillon doit être NON VIVANT")
        # Tourbillon a haute cohérence MAIS pas de mémoire ni causalité
        self.assertGreater(result['S0'], self.law.S_crit, "Tourbillon a haute cohérence")
        self.assertLess(result['Delta_C_memory'], 0.3, "Tourbillon n'a pas de mémoire")
    
    def test_crystal_classification(self):
        """Test: cristal doit être classifié NON VIVANT"""
        data = generate_synthetic_nonliving_system('crystal', N=30, T=80, seed=42)
        result = self.law.full_analysis(**data)
        
        self.assertFalse(result['is_living'], "Cristal doit être NON VIVANT")
        self.assertLess(result['Delta_C_causal'], 1.0, "Cristal est inerte")
    
    def test_memory_test_significance(self):
        """Test de la significativité statistique du test mémoire"""
        # Réponses corrélées (mémoire présente)
        R1 = np.random.randn(50, 1)
        R2 = 0.8 * R1 + 0.2 * np.random.randn(50, 1)
        
        Delta_C_mem, p_val = self.law.test_memory([(R1, R2)])
        
        self.assertGreater(Delta_C_mem, 0.5, "Forte mémoire attendue")
        self.assertLess(p_val, 0.05, "Doit être statistiquement significatif")
    
    def test_autonomous_causality_baseline(self):
        """Test production d'entropie vs baseline"""
        # États avec forte dynamique
        states_active = np.cumsum(np.random.randn(100, 5), axis=0)
        Delta_C_caus_active, _ = self.law.test_autonomous_causality(states_active, baseline_entropy=0.01)
        
        # États statiques
        states_static = np.ones((100, 5))
        Delta_C_caus_static, _ = self.law.test_autonomous_causality(states_static, baseline_entropy=0.01)
        
        self.assertGreater(Delta_C_caus_active, Delta_C_caus_static,
                          "Système actif doit avoir plus de causalité que système statique")
    
    def test_classification_edge_cases(self):
        """Test cas limites de classification"""
        # Cas 1: S₀ élevé, mais pas de mémoire ni causalité
        result1 = self.law.classify_system(S0=5.0, Delta_C_memory=0.0, Delta_C_causal=0.0)
        self.assertFalse(result1['is_living'])
        
        # Cas 2: Mémoire et causalité, mais S₀ faible
        result2 = self.law.classify_system(S0=0.5, Delta_C_memory=0.8, Delta_C_causal=2.0)
        self.assertFalse(result2['is_living'])
        
        # Cas 3: Tout satisfait
        result3 = self.law.classify_system(S0=2.0, Delta_C_memory=0.7, Delta_C_causal=3.0)
        self.assertTrue(result3['is_living'])
    
    def test_reproducibility(self):
        """Test de la reproductibilité avec seed fixe"""
        data1 = generate_synthetic_living_system(N=20, T=50, seed=123)
        data2 = generate_synthetic_living_system(N=20, T=50, seed=123)
        
        result1 = self.law.full_analysis(**data1)
        result2 = self.law.full_analysis(**data2)
        
        self.assertAlmostEqual(result1['S0'], result2['S0'], places=5)
        self.assertAlmostEqual(result1['Delta_C_memory'], result2['Delta_C_memory'], places=5)


def run_full_test_suite():
    """Lance la suite complète de tests"""
    print("=" * 70)
    print("LOI DU VIVANT Ω⁹ - SUITE DE TESTS")
    print("=" * 70)
    print()
    
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromTestCase(TestLawOfLivingOmega9)
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    print()
    print("=" * 70)
    if result.wasSuccessful():
        print("✓ TOUS LES TESTS RÉUSSIS")
    else:
        print(f"✗ {len(result.failures)} ÉCHEC(S), {len(result.errors)} ERREUR(S)")
    print("=" * 70)
    
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_full_test_suite()
    exit(0 if success else 1)
